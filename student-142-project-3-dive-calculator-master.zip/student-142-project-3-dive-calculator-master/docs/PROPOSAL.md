# CPTR 142 Project III: WWU Information Management

## Problem Definition

The goal for this project is to build a dive calculator that performs various calculations and looks up data for a commercial diver. 
The data is relative to the individual dives conducted by one person.

### Key Features

* Repet group designation
* RNT calculations

### Assumptions

The users of the system are good actors. 
No security (authtentication and permissions) will be implemented for this project.

## Group Members

* Josh Garbi
* Anna Caraveo
* Paul Hartman
* Keaton Reece
