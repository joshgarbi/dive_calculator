/**
 * Project III: Start here.
 */
#pragma once

#include <string>

std::string helloWorld();
