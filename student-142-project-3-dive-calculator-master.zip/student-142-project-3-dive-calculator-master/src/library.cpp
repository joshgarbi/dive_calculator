/**
 * Project III: Start here.
 */
#include <string>

std::string helloWorld() { return "Hello World!"; }
