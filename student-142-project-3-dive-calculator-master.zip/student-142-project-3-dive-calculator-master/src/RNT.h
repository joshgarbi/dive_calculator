#pragma once

//class definition for residual nitrogen time
class Residual_time{
    public:
        int RNT(char repet_group, double SI_time, int depth);

};
